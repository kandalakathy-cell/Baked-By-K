
/* Welcome message for Baked by B */

/* Show the welcome message only on the Home page */

window.addEventListener("load", function() {

    if (
        window.location.pathname.endsWith("/index.html") ||
        window.location.pathname.endsWith("/")
    ) {
        alert("Welcome to Baked by K! We are happy to have you here.");
    }

});


/* Validate the custom order form */
document.addEventListener("DOMContentLoaded", function () {

    const orderForm = document.getElementById("orderForm");

    // Only run this code on the page with the order form
    if (orderForm) {

        orderForm.addEventListener("submit", function (event) {

            const phone = orderForm.elements["phone"].value.trim();
            const eventDate = orderForm.elements["eventDate"].value;
            const message = document.getElementById("formMessage");

            // Clear the previous message
            message.textContent = "";
            message.style.color = "red";

            // Check that the phone number contains 10 digits
            if (!/^\d{10}$/.test(phone)) {
                event.preventDefault();
                message.textContent =
                    "Please enter a valid 10-digit phone number.";
                return;
            }

            // Check that the event date is not in the past
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            if (eventDate && new Date(eventDate + "T00:00:00") < today) {
                event.preventDefault();
                message.textContent =
                    "Please choose today or a future event date.";
                return;
            }

            // Show booking request confirmation
event.preventDefault();
message.style.color = "green";
message.textContent =
    "Thank you for choosing Baked by K! Your booking request has been received. We will contact you soon to confirm your order.";

        });
    }
});


// Product search feature
document.addEventListener("DOMContentLoaded", function () {

    const searchBox = document.getElementById("productSearch");

    // Only run this feature on the products page
    if (searchBox) {

        const categories = [
            document.getElementById("birthdayCakes"),
            document.getElementById("cupcakes"),
            document.getElementById("cookies"),
            document.getElementById("otherDesserts")
        ];

        const message = document.getElementById("searchMessage");

        searchBox.addEventListener("input", function () {

            const searchText = searchBox.value.toLowerCase().trim();
            let found = false;

            categories.forEach(function (heading) {

                const section = heading.parentElement;
                let showSection = searchText === "" ||
                    heading.textContent.toLowerCase().includes(searchText);

                // Include the matching section's description and images
                let nextElement = heading.nextElementSibling;

                while (nextElement && nextElement.tagName !== "H2") {
                    if (showSection) {
                        nextElement.style.display = "";
                    } else {
                        nextElement.style.display = "none";
                    }
                    nextElement = nextElement.nextElementSibling;
                }

                heading.style.display = showSection ? "" : "none";

                if (showSection) {
                    found = true;
                }
            });

            if (searchText === "") {
                message.textContent = "";
            } else if (found) {
                message.textContent = "Matching products are shown below.";
            } else {
                message.textContent = "No matching products found. Try cakes, cupcakes, cookies or desserts.";
            }
        });
    }
});


// Show or hide weekly offers
document.addEventListener("DOMContentLoaded", function () {

    const offersButton = document.getElementById("offersButton");
    const weeklyOffers = document.getElementById("weeklyOffers");

    if (offersButton && weeklyOffers) {

        offersButton.addEventListener("click", function () {

            if (weeklyOffers.style.display === "none") {
                weeklyOffers.style.display = "block";
                offersButton.textContent = "🎀 Hide Weekly Offers";
            } else {
                weeklyOffers.style.display = "none";
                offersButton.textContent = "🧁 Show Weekly Offers";
            }

        });
    }
});


/* Validate the contact form */
document.addEventListener("DOMContentLoaded", function () {

    const contactForm = document.getElementById("contactForm");

    // Only run this code on the contact page
    if (contactForm) {

        contactForm.addEventListener("submit", function (event) {

            const phone = document.getElementById("contactPhone").value.trim();
            const message = document.getElementById("contactFormMessage");

            // Clear the previous message
            message.textContent = "";
            message.style.color = "red";

            // Check that the phone number contains 10 digits
            const phoneDigits = phone.replace(/\D/g, "");

            if (phoneDigits.length !== 10) {
                event.preventDefault();
                message.textContent =
                    "Please enter a valid phone number with 10 digits.";
                return;
            }

        
        
// Prepare an email with the customer's details
event.preventDefault();

const name = document.getElementById("contactName").value.trim();
const email = document.getElementById("contactEmail").value.trim();
const customerMessage = document.getElementById("contactMessage").value.trim();

const subject = encodeURIComponent("Message from Baked by K website");
const body = encodeURIComponent(
    "Name: " + name +
    "\nEmail: " + email +
    "\nPhone: " + phone +
    "\n\nMessage:\n" + customerMessage
);

// Open the customer's email app with the details filled in
window.location.href =
    "mailto:bakedbyK@gmail.com?subject=" + subject + "&body=" + body;
    
        });
    }
});

/* Calculate the estimated preparation time for custom orders */
document.addEventListener("DOMContentLoaded", function () {

    const orderForm = document.getElementById("orderForm");
    const eventDateInput = document.querySelector(
        '#orderForm input[name="eventDate"]'
    );
    const etaMessage = document.getElementById("etaMessage");

    // Only run this feature on the custom orders page
    if (orderForm && eventDateInput && etaMessage) {

        eventDateInput.addEventListener("change", function () {

            if (!eventDateInput.value) {
                etaMessage.textContent = "";
                return;
            }

            const eventDate = new Date(
                eventDateInput.value + "T00:00:00"
            );

            const earliestOrderDate = new Date(eventDate);
            earliestOrderDate.setDate(
                earliestOrderDate.getDate() - 7
            );

            const latestOrderDate = new Date(eventDate);
            latestOrderDate.setDate(
                latestOrderDate.getDate() - 5
            );

            etaMessage.style.color = "brown";
            etaMessage.textContent =
                "Preparation reminder: Please place your order between " +
                earliestOrderDate.toLocaleDateString() +
                " and " +
                latestOrderDate.toLocaleDateString() +
                ". This is a suggested ordering period, not a confirmed collection or delivery time.";
        });
    }
});